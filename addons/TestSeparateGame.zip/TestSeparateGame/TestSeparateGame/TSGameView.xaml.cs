﻿using System.Windows;
using Games.Core;

namespace TestSeparateGame
{
    public partial class TSGameView : IGame
    {
        public TSGameView()
        {
            InitializeComponent();
        }

        public event GameStepEventHandler GameStep;

        public void OnGameStep()
        {
        }

        public void Redo()
        {
        }

        public object Settings
        {
            set {}
        }

        public void SolutionPause()
        {
        }

        public void SolutionStart()
        {
        }

        public void SolutionStop()
        {
        }

        public void Start()
        {
        }

        public void Undo()
        {
        }

        public FrameworkElement View
        {
            get { return this; }
        }
    }
}
