﻿using Games.Core;

namespace TestSeparateGame
{
    public class TSInfo : IGameInfo
    {
        public TSInfo()
        {
            _name = "Test separated 1.0";
            _contentType = typeof (TSContent);
        }
    }
}
