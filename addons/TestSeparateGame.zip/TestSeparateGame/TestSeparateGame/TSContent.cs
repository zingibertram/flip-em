﻿using Games.Core;

namespace TestSeparateGame
{
    public class TSContent : IGameViews
    {
        public TSContent()
        {
            _game = new TSGameView();
            _settings = new TSSettingsView();
        }
    }
}
