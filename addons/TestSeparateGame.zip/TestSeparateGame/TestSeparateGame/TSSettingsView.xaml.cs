﻿using System.Windows;
using Games.Core;

namespace TestSeparateGame
{
    public partial class TSSettingsView : ISettings
    {
        public TSSettingsView()
        {
            InitializeComponent();
        }

        public object Settings
        {
            get { return null; }
        }

        public FrameworkElement View
        {
            get { return this; }
        }
    }
}
